# Sigma Prim's Site

A free, responsive portfolio website made with plain HTML, CSS and JavaScript.

## Add photos

1. Open the `images` folder.
2. Put your pictures there.
3. Name them `photo-1.jpg`, `photo-2.jpg`, etc.
4. Open `index.html` in a browser to preview.

You can also change the image filenames in the Gallery section of `index.html`.

## Publish for free with GitHub Pages

1. Create a GitHub account.
2. Create a repository named `YOURUSERNAME.github.io`.
3. Upload `index.html`, `style.css`, `script.js`, the `README.md`, and the `images` folder.
4. In the repository, open **Settings → Pages**.
5. Under the publishing/source option, choose the main branch and root folder.
6. Your site will be available at `https://YOURUSERNAME.github.io`.

## Edit the site

Everything is plain HTML/CSS/JavaScript, so you can edit it in GitHub's browser editor or a code editor on your computer.

For a public website, avoid posting private information such as your home address, personal phone number, school details, passwords, or other sensitive information.
